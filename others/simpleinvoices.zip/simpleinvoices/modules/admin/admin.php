<?php
/*
* Script: admin.php
* 	admin page
*
* Authors:
*	 Nicolas Ruflin
*
* Last edited:
* 	 2007-07-19
*
* License:
*	 GPL v2 or above
*
* Website:
* 	http://www.simpleinvoices.org
*/

checkLogin();

echo <<<EOD
<h2>Admin Functions</h2>
<ul>
	<li>Cache Cleanup</li>
</ul>
EOD;

?>
