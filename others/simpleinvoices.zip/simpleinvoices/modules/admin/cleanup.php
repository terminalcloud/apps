<?php
/*
* Script: cleanup.php
* 	cleanup page
*
* Authors:
*	 Nicolas Ruflin
*
* Last edited:
* 	 2007-07-19
*
* License:
*	 GPL v2 or above
*
* Website:
* 	http://www.simpleinvoices.org
 */

echo "should dele all files in the cache folder...";

?>
