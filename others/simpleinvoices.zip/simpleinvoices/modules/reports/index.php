<?php
$smarty -> assign('pageActive', 'report');
$smarty -> assign('active_tab', '#home');
?>
