<?php

$ni = new invoice();
$ni->id = $_GET['id'];
$ni->recur();
