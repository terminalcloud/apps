<?php
$smarty -> assign('pageActive', 'setting');
$smarty -> assign('active_tab', '#setting');
?>
