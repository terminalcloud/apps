<?php
$menu=false;
include_once("./extensions/text_ui/include/sql_queries.php");

?>
