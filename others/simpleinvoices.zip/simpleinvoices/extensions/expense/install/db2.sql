ALTER TABLE `si_expense` ADD `status` INT( 1 ) NOT NULL 
