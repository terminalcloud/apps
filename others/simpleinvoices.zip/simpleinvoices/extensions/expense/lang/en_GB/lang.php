<?php


$LANG['expense'] = "Expense";//1
$LANG['paid'] = "Paid";//1
$LANG['not_paid'] = "Not paid";//1
$LANG['expense_account'] = "Expense account";//1
$LANG['accounts'] = "Accounts";//1
$LANG['save_expense_failure'] = "Something went wrong, please try saving the expense again<br />";//1
$LANG['save_expense_success'] = "Expense successfully saved, <br /> you will be redirected to the Expenses page";//1
$LANG['add_new_expense'] = "Add new expense";//1
$LANG['add_new_expense_account'] = "Add new account";//1
