DISCLAIMER
--------------------------
Software downloaded from the eWAY web site is provided 'as is' without warranty of any kind,
either express or implied, including, but not limited to; the implied warranties of fitness for a purpose,
or the warranty of non-infringement.

Without limiting the foregoing, the eWAY makes no warranty that:

- The software will meet your requirements.

- The software will be uninterrupted, timely, secure or error-free.

- The quality of the software will meet your expectations.


Software and its documentation made available on the eWAY web site could include technical or other mistakes,
inaccuracies or typographical errors. eWAY may make changes at any time to the software or documentation made
available on its web site.


eWAY assumes no responsibility for errors or omissions in the software or documentation available from its web site.

==============================