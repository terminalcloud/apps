Invoice Template: Grouped
Purposed: group products by a custom field (1) 
Note: 
 1: edit product custom field 1 to be 'Grouping'
 2: fill in the 'Grouping' for each product
