Application:
 * Simple Invoices

Homepage:
 * http://simpleinvoices.org

Documentation:
 * Installation: http://simpleinvoices.org/install
 * Frequently Asked Questions: http://simpleinvoices.org/wiki/faqs
 * Help: http://simpleinvoices.org/help

About:
 * Simple Invoices is released under the GPL v3 license - refer license.txt for details
 * For installation instructions refer: http://simpleinvoices.org/install
 * For any other help or comments jump on our website or post on the forum at http://simpleinvoices.org/forum


