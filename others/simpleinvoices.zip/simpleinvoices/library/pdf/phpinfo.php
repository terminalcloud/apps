<?php
phpinfo(); 
?>
