<?php

// module/StickyNotes/autoload_classmap.php
return array();