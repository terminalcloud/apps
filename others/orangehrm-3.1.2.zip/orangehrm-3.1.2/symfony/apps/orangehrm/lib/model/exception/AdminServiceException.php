<?php
class AdminServiceException extends ServiceException
{
	
}