<?php

/**
 * ReportTo filter form.
 *
 * @package    filters
 * @subpackage ReportTo *
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 11675 2008-09-19 15:21:38Z fabien $
 */
class ReportToFormFilter extends BaseReportToFormFilter
{
  public function configure()
  {
  }
}