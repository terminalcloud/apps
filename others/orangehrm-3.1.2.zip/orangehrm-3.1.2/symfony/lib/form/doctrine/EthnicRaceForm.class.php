<?php

/**
 * EthnicRace form.
 *
 * @package    form
 * @subpackage EthnicRace
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class EthnicRaceForm extends BaseEthnicRaceForm
{
  public function configure()
  {
  }
}