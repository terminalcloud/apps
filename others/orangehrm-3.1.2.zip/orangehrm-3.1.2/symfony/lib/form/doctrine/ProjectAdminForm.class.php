<?php

/**
 * ProjectAdmin form.
 *
 * @package    form
 * @subpackage ProjectAdmin
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class ProjectAdminForm extends BaseProjectAdminForm
{
  public function configure()
  {
  }
}