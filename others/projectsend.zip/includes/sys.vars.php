<?php
/**
 * ProjectSend system constants
 *
 * Left here for backwards compatibility, since this file is directly
 * loaded by the index.php file generated on the clients folders.
 *
 * @package ProjectSend
 * @deprecated Since r120
 */
require_once('../../includes/sys.vars.php');
require_once('../../sys.includes.php');
?>