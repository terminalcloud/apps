	<?php
	/**
	 * Footer for the backend. Outputs the default mark up and
	 * information generated on functions.php.
	 *
	 * @package ProjectSend
	 */
	default_footer_info();
	?>

</body>
</html>
<?php ob_end_flush(); ?>