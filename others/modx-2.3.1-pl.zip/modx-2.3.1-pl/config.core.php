<?php
define('MODX_CORE_PATH', dirname(__FILE__) . '/core/');
define('MODX_CONFIG_KEY', 'config');
