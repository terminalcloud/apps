Text file to ensure this folder is created on the server.

Projects created by users will be stored in this folder.