<?php
	function tpl_function_checkForJs($params, &$smarty)
	{
		check_for_js();
	}
?>