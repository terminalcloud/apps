
			</div>
		</div><!--/.row-->
	</section><!--/#maincontent-->
	<hr />
	<footer class="footer">
		<div id="footer">
			<span class="subtext"> 
				<a href="http://pligg.com/" target="_blank">Pligg Content Management System</a> 
				| Need Web Hosting? Check out our <a href="http://pligg.com/hosting/" target="_blank">Preferred Web Hosts</a> 
			</span>
		</div>
	</footer>
</div><!--/.container-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/themes/smoothness/jquery-ui.css" media="all" rel="stylesheet" type="text/css" />

<!--[if lt IE 7]>
<script type="text/javascript" src="../templates/admin/js/jquery/jquery.dropdown.js"></script>
<![endif]-->

<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>

</body>
</html>