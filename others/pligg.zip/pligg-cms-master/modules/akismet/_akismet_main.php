<?php

function akismet_save_comment($x){
print_r($x);
	echo "this is php version".phpnum();
}

?>
