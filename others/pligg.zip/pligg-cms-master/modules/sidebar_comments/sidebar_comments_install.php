<?php
	$module_info['name'] = 'Sidebar Comments';
	$module_info['desc'] = 'Displays the most recent comments in the sidebar';
	$module_info['version'] = 2.0;
	$module_info['update_url'] = 'http://pligg.com/downloads/module/sidebar-comments/version/';
	$module_info['homepage_url'] = 'http://pligg.com/downloads/module/sidebar-comments/';

?>