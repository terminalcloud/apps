<?php
	$module_info['name'] = 'Links';
	$module_info['desc'] = 'Replaces "http://" URLs in comments and stories with a clickable URL.';
	$module_info['version'] = 1.0;
	$module_info['settings_url'] = '../module.php?module=links';
	$module_info['homepage_url'] = 'http://pligg.com/downloads/module/links/';
	$module_info['update_url'] = 'http://pligg.com/downloads/module/links/version/';
	
?>
