<?php
	$module_info['name'] = 'Sidebar Tag';
	$module_info['desc'] = 'Displays the tag cloud in the sidebar.';
	$module_info['version'] = 2.0;
	$module_info['update_url'] = 'http://pligg.com/downloads/module/sidebar-tag-cloud/version/';
	$module_info['homepage_url'] = 'http://pligg.com/downloads/module/sidebar-tag-cloud/';
	
?>
