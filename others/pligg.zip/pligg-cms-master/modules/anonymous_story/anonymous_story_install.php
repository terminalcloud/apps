<?php	
	$module_info['name'] = 'Anonymous Story';
	$module_info['desc'] = 'Allows any user to submit a story without registering an account.';
	$module_info['version'] = 0.1;
	$module_info['requires'][] = array('anonymous', 0.1, 'Anonymous Mode', '');
	$module_info['requires'][] = array('hc', 1, 'Human Check', '');
?>