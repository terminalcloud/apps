<?php
	$module_info['name'] = 'Sidebar Saved';
	$module_info['desc'] = 'Displays recently saved stories in the sidebar for logged in members.';
	$module_info['version'] = 2.1;
	$module_info['update_url'] = 'http://pligg.com/downloads/module/sidebar-saved/version/';
	$module_info['homepage_url'] = 'http://pligg.com/downloads/module/sidebar-saved/';
	
?>
