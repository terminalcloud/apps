﻿<?php
	$module_info['name'] = 'Simple Private Messaging';
	$module_info['desc'] = 'Let users send private messages to each other.';
	$module_info['version'] = 2.4;
	$module_info['homepage_url'] = 'http://pligg.com/downloads/module/simple-messaging/';
	$module_info['update_url'] = 'http://pligg.com/downloads/module/simple-messaging/version/';

?>