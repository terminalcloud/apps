<?php
	$module_info['name'] = 'Send Welcome Private Message';
	$module_info['desc'] = 'Sends a private message to new users welcoming them to the site.';
	$module_info['version'] = 2.0;
	$module_info['requires'][] = array('simple_messaging', 2.0, 'Simple Private Messaging', '');
?>