<?php	

if(!defined('mnminclude')){header('Location: ../error_404.php');die();}

if(Enable_Extra_Fields){
	if(Enable_Extra_Field_1){
		$main_smarty->assign('Enable_Extra_Field_1', Enable_Extra_Field_1);
		$main_smarty->assign('Field_1_Title', Field_1_Title);
		$main_smarty->assign('Field_1_Instructions', Field_1_Instructions);
		$main_smarty->assign('Field_1_Required', Field_1_Required);
		$main_smarty->assign('Field_1_Validation_Method', Field_1_Validation_Method);
		$main_smarty->assign('Field_1_Validation_Error_Message', Field_1_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_2){
		$main_smarty->assign('Enable_Extra_Field_2', Enable_Extra_Field_2);
		$main_smarty->assign('Field_2_Title', Field_2_Title);
		$main_smarty->assign('Field_2_Instructions', Field_2_Instructions);
		$main_smarty->assign('Field_2_Required', Field_2_Required);
		$main_smarty->assign('Field_2_Validation_Method', Field_2_Validation_Method);
		$main_smarty->assign('Field_2_Validation_Error_Message', Field_2_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_3){
		$main_smarty->assign('Enable_Extra_Field_3', Enable_Extra_Field_3);
		$main_smarty->assign('Field_3_Title', Field_3_Title);
		$main_smarty->assign('Field_3_Instructions', Field_3_Instructions);
		$main_smarty->assign('Field_3_Required', Field_3_Required);
		$main_smarty->assign('Field_3_Validation_Method', Field_3_Validation_Method);
		$main_smarty->assign('Field_3_Validation_Error_Message', Field_3_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_4){
		$main_smarty->assign('Enable_Extra_Field_4', Enable_Extra_Field_4);
		$main_smarty->assign('Field_4_Title', Field_4_Title);
		$main_smarty->assign('Field_4_Instructions', Field_4_Instructions);
		$main_smarty->assign('Field_4_Required', Field_4_Required);
		$main_smarty->assign('Field_4_Validation_Method', Field_4_Validation_Method);
		$main_smarty->assign('Field_4_Validation_Error_Message', Field_4_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_5){
		$main_smarty->assign('Enable_Extra_Field_5', Enable_Extra_Field_5);
		$main_smarty->assign('Field_5_Title', Field_5_Title);
		$main_smarty->assign('Field_5_Instructions', Field_5_Instructions);
		$main_smarty->assign('Field_5_Required', Field_5_Required);
		$main_smarty->assign('Field_5_Validation_Method', Field_5_Validation_Method);
		$main_smarty->assign('Field_5_Validation_Error_Message', Field_5_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_6){
		$main_smarty->assign('Enable_Extra_Field_6', Enable_Extra_Field_6);
		$main_smarty->assign('Field_6_Title', Field_6_Title);
		$main_smarty->assign('Field_6_Instructions', Field_6_Instructions);
		$main_smarty->assign('Field_6_Required', Field_6_Required);
		$main_smarty->assign('Field_6_Validation_Method', Field_6_Validation_Method);
		$main_smarty->assign('Field_6_Validation_Error_Message', Field_6_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_7){
		$main_smarty->assign('Enable_Extra_Field_7', Enable_Extra_Field_7);
		$main_smarty->assign('Field_7_Title', Field_7_Title);
		$main_smarty->assign('Field_7_Instructions', Field_7_Instructions);
		$main_smarty->assign('Field_7_Required', Field_7_Required);
		$main_smarty->assign('Field_7_Validation_Method', Field_7_Validation_Method);
		$main_smarty->assign('Field_7_Validation_Error_Message', Field_7_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_8){
		$main_smarty->assign('Enable_Extra_Field_8', Enable_Extra_Field_8);
		$main_smarty->assign('Field_8_Title', Field_8_Title);
		$main_smarty->assign('Field_8_Instructions', Field_8_Instructions);
		$main_smarty->assign('Field_8_Required', Field_8_Required);
		$main_smarty->assign('Field_8_Validation_Method', Field_8_Validation_Method);
		$main_smarty->assign('Field_8_Validation_Error_Message', Field_8_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_9){
		$main_smarty->assign('Enable_Extra_Field_9', Enable_Extra_Field_9);
		$main_smarty->assign('Field_9_Title', Field_9_Title);
		$main_smarty->assign('Field_9_Instructions', Field_9_Instructions);
		$main_smarty->assign('Field_9_Required', Field_9_Required);
		$main_smarty->assign('Field_9_Validation_Method', Field_9_Validation_Method);
		$main_smarty->assign('Field_9_Validation_Error_Message', Field_9_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_10){
		$main_smarty->assign('Enable_Extra_Field_10', Enable_Extra_Field_10);
		$main_smarty->assign('Field_10_Title', Field_10_Title);
		$main_smarty->assign('Field_10_Instructions', Field_10_Instructions);
		$main_smarty->assign('Field_10_Required', Field_10_Required);
		$main_smarty->assign('Field_10_Validation_Method', Field_10_Validation_Method);
		$main_smarty->assign('Field_10_Validation_Error_Message', Field_10_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_11){
		$main_smarty->assign('Enable_Extra_Field_11', Enable_Extra_Field_11);
		$main_smarty->assign('Field_11_Title', Field_11_Title);
		$main_smarty->assign('Field_11_Instructions', Field_11_Instructions);
		$main_smarty->assign('Field_11_Required', Field_11_Required);
		$main_smarty->assign('Field_11_Validation_Method', Field_11_Validation_Method);
		$main_smarty->assign('Field_11_Validation_Error_Message', Field_11_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_12){
		$main_smarty->assign('Enable_Extra_Field_12', Enable_Extra_Field_12);
		$main_smarty->assign('Field_12_Title', Field_12_Title);
		$main_smarty->assign('Field_12_Instructions', Field_12_Instructions);
		$main_smarty->assign('Field_12_Required', Field_12_Required);
		$main_smarty->assign('Field_12_Validation_Method', Field_12_Validation_Method);
		$main_smarty->assign('Field_12_Validation_Error_Message', Field_12_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_13){
		$main_smarty->assign('Enable_Extra_Field_13', Enable_Extra_Field_13);
		$main_smarty->assign('Field_13_Title', Field_13_Title);
		$main_smarty->assign('Field_13_Instructions', Field_13_Instructions);
		$main_smarty->assign('Field_13_Required', Field_13_Required);
		$main_smarty->assign('Field_13_Validation_Method', Field_13_Validation_Method);
		$main_smarty->assign('Field_13_Validation_Error_Message', Field_13_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_14){
		$main_smarty->assign('Enable_Extra_Field_14', Enable_Extra_Field_14);
		$main_smarty->assign('Field_14_Title', Field_14_Title);
		$main_smarty->assign('Field_14_Instructions', Field_14_Instructions);
		$main_smarty->assign('Field_14_Required', Field_14_Required);
		$main_smarty->assign('Field_14_Validation_Method', Field_14_Validation_Method);
		$main_smarty->assign('Field_14_Validation_Error_Message', Field_14_Validation_Error_Message);
	}	

	if(Enable_Extra_Field_15){
		$main_smarty->assign('Enable_Extra_Field_15', Enable_Extra_Field_15);
		$main_smarty->assign('Field_15_Title', Field_15_Title);
		$main_smarty->assign('Field_15_Instructions', Field_15_Instructions);
		$main_smarty->assign('Field_15_Required', Field_15_Required);
		$main_smarty->assign('Field_15_Validation_Method', Field_15_Validation_Method);
		$main_smarty->assign('Field_15_Validation_Error_Message', Field_15_Validation_Error_Message);
	}	

}
?>