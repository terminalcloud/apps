<?php
#**************************************************************************
#  openSIS is a free student information system for public and non-public 
#  schools from Open Solutions for Education, Inc. web: www.os4ed.com
#
#  openSIS is  web-based, open source, and comes packed with features that 
#  include student demographic info, Timetable, grade book, attendance, 
#  report cards, eligibility, transcripts, parent portal, 
#  student portal and more.   
#
#  Visit the openSIS web site at http://www.opensis.com to learn more.
#  If you have question regarding this system or the license, please send 
#  an email to info@os4ed.com.
#
#  This program is released under the terms of the GNU General Public License as  
#  published by the Free Software Foundation, version 2 of the License. 
#  See license.txt.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#***************************************************************************************
include('../../../Redirect_includes.php');
include_once('modules/School_Setup/includes/functions.php');
$fields_RET = DBGet(DBQuery("SELECT ID,TITLE,TYPE,SELECT_OPTIONS,DEFAULT_SELECTION,REQUIRED,HIDE FROM school_custom_fields WHERE SYSTEM_FIELD = 'N' AND SCHOOL_ID='".UserSchool()."' ORDER BY SORT_ORDER,TITLE"));

if(UserSchool())
{
	$custom_RET = DBGet(DBQuery("SELECT * FROM schools WHERE ID='".  UserSchool()."'"));
	$value = $custom_RET[1];
}
$num_field_gen=true;
if(count($fields_RET))
{
//echo '<TABLE cellpadding=5>';
$i = 1;
foreach($fields_RET as $field)
{
    if($field['HIDE']=='Y')
        continue;
//if($field['REQUIRED']=='Y'){
//$req='<font color=red>*</font> ';
//}else{
//$req='';
//}
	switch($field['TYPE'])
	{
		case 'text':
			echo '<TR>';
			echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
			echo _makeTextInputSchl('CUSTOM_'.$field['ID'],'','class=cell_floating size=24');
			echo '</TD>';
			echo '</TR>';
			break;

		case 'autos':
			echo '<TR>';
			echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
			echo _makeAutoSelectInputSchl('CUSTOM_'.$field['ID'],'');
			echo '</TD>';
			echo '</TR>';
			break;

		case 'edits':
			echo '<TR>';
			echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
			echo _makeAutoSelectInputSchl('CUSTOM_'.$field['ID'],'');
			echo '</TD>';
			echo '</TR>';
			break;

		case 'numeric':
			echo '<TR>';
			echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
			echo _makeTextInputSchl('CUSTOM_'.$field['ID'],'','size=5 maxlength=10 class=cell_medium');
			echo '</TD>';
			echo '</TR>';
			break;

		case 'date':
			echo '<TR>';
			echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
			echo _makeDateInput_modSchl('CUSTOM_'.$field['ID'],'');
			echo '</TD>';
			echo '</TR>';
			break;

		case 'codeds':
		case 'select':
			echo '<TR>';
			echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
			echo _makeSelectInputSchl('CUSTOM_'.$field['ID'],'');
			echo '</TD>';
			echo '</TR>';
			break;

		case 'multiple':
			echo '<TR>';
			echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
			echo _makeMultipleInputSchl('CUSTOM_'.$field['ID'],'');
			echo '</TD>';
			echo '</TR>';
			break;

		case 'radio':
			echo '<TR>';
			echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
			echo _makeCheckboxInputSchl('CUSTOM_'.$field['ID'],'');
			echo '</TD>';
			echo '</TR>';
			break;

               case 'textarea':	
                       echo '<TR>';
		       echo '<td class="label"><b>'.$req.$field['TITLE'].'</b>:</td><td>';
		       echo _makeTextareaInputSchl('CUSTOM_'.$field['ID'],'');
		       echo '</TD>';
		       echo '</TR>';
                       break;
	}
}
//echo '</TABLE>';
}
?>
