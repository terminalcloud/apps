<?php

# This file serves only to call other scheduled processes.

include(dirname(__FILE__) . "/../pages/tools/cron_copy_hitcount.php");

?>
