<?php
# Date uses same code as date + time
include "4.php";
