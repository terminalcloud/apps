<?php /* -------- Expiry date --------------------- */ 

# Uses same code as date.
include "4.php";
