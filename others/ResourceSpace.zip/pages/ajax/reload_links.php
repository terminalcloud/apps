<?php

include_once('../../include/db.php');
include_once('../../include/general.php');
include_once('../../include/authenticate.php');
include_once('../../include/search_functions.php');
include_once('../../include/header_links.php');