#!/bin/bash
SUPPORTED_OS='CentOS|Red Hat Enterprise Linux Server|Fedora'
PROD_NAME="Zend Server"

if ! egrep -q "$SUPPORTED_OS" /etc/issue ; then
cat <<EOF

This script is meant for upgrading the $PROD_NAME PHP version for RPM based systems.
If you're using Debian or Ubuntu, simply run:
# aptitude install zend-server-php-5.3
Or, to install $PROD_NAME CE:
# aptitude install zend-server-ce-php-5.3 
as super user.

EOF
    exit 1
fi

if [ $# -lt 1 ]; then
cat <<EOF

Usage: $0 <php_version> [ce]
Where php_version is either 5.2 or 5.3. Pass ce as a second argument if you wish to install the Community edition.

EOF
    exit 1
else
    PHP_VER=$1
fi
if [ "$2" = 'ce' ];then
    META_PACK_NAME="zend-server-ce-php-$PHP_VER"
else
    META_PACK_NAME="zend-server-php-$PHP_VER"
fi
MYUID=`id -u 2> /dev/null`
if [ ! -z "$MYUID" ]; then
    if [ $MYUID != 0 ]; then
        echo "You need root privileges to run this script.";
        exit 1
    fi
else
    echo "Could not detect UID";
    exit 1
fi
# get the currently installed package
CUR_ZS_META=`rpm -qa --qf "[%{NAME}]" "zend-server-*php-5.*"`
# if we got nothing, lets just display $PROD_NAME in our question..
if [ -z "$CUR_ZS_META" ];then
    CUR_ZS_META=$PROD_NAME
fi
cat <<EOF

Running this script will preform the following:
* Configure your package manager to use $PROD_NAME repository 
* Remove the previous $PROD_NAME installation if it exists
* Install $PROD_NAME PHP $PHP_VER on your system using your package manager
* Restore old configuration files

Would you like to switch $CUR_ZS_META to PHP $PHP_VER ($META_PACK_NAME)? [N/Y]
EOF
read ANS
if [ "$ANS" != 'Y' ];then
    echo "Aborting."
    exit 1
fi
if  `which yum &>/dev/null` ;then
    REPO_FILE=`dirname $0`/zend.repo.rpm
    TARGET_REPO_FILE=/etc/yum.repos.d/zend.repo
    TOOL="yum -y"
    SYNC_COMM="$TOOL clean all"
else
    echo "Could not find yum in PATH!"
    exit 1
fi
cp $REPO_FILE $TARGET_REPO_FILE
$SYNC_COMM
$TOOL remove "zend-server*-php-5.*" && yum remove "*zend*"
$TOOL install $META_PACK_NAME
if [ $? -eq 0 ]; then
    echo "$PROD_NAME was successfully installed."
    echo "Restoring *.rpmsave files..."
    for conffile in `find /usr/local/zend/ -name "*.rpmsave"`;do echo "Restoring $conffile" ;mv $conffile `echo $conffile|sed 's@.rpmsave@@'`;done
else
    echo "$PROD_NAME Installation was not completed. See $TOOL output above for detailed error information."
fi

