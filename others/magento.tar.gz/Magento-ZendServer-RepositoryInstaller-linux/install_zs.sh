#!/bin/bash
SUPPORTED_OS='CentOS|Red Hat Enterprise Linux Server|Fedora|Debian GNU/Linux|Ubuntu'
PROD_NAME="Zend Server"

if ! egrep -q "$SUPPORTED_OS" /etc/issue ; then
cat <<EOF

Unable to install: Your distribution is not suitable for installation using
Zend's DEB/RPM repositories. You can install Zend Server Community Edition on
most Linux distributions using the generic tarball installer. For more 
information, see http://www.zend.com/en/community/zend-server-ce

EOF
    exit 1
fi

if [ "$1" = 'ce' ];then
    META_PACK_NAME="zend-server-ce-php-5.2"
else
    META_PACK_NAME="zend-server-php-5.2"
fi
MYUID=`id -u 2> /dev/null`
if [ ! -z "$MYUID" ]; then
    if [ $MYUID != 0 ]; then
        echo "You need root privileges to run this script.";
        exit 1
    fi
else
    echo "Could not detect UID";
    exit 1
fi
# first, lets figure if we're aptitude or yum
cat <<EOF

Running this script will preform the following:
* Configure your package manager to use $PROD_NAME repository 
* Install $PROD_NAME on your system using your package manager
* Install Magento and $PROD_NAME on your system using your package manager

Hit ENTER to install $PROD_NAME, or Ctrl+C to abort now.
EOF
read 
if  `which yum &>/dev/null` ;then
    REPO_FILE=`dirname $0`/zend.repo.rpm
    TARGET_REPO_FILE=/etc/yum.repos.d/zend.repo
    TOOL=yum
    SYNC_COMM="$TOOL clean all"
    META_PACK_NAME="$META_PACK_NAME magento-zend-quick-setup"
elif `which aptitude &>/dev/null`;then
    REPO_FILE=`dirname $0`/zend.repo.deb
    TARGET_REPO_FILE=/etc/apt/sources.list.d/zend.list
    TOOL=aptitude
    SYNC_COMM="$TOOL update"
    wget http://repos.zend.com/deb/zend.key -O- | apt-key add -
fi
cp $REPO_FILE $TARGET_REPO_FILE
$SYNC_COMM
$TOOL install $META_PACK_NAME
if [ $? -eq 0 ]; then
    echo "$PROD_NAME was successfully installed."
else
    echo "$PROD_NAME Installation was not completed. See $TOOL output above for detailed error information."
fi

