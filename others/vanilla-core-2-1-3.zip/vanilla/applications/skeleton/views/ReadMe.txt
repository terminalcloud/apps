The default theme does not have any customized views. 
If you were creating a theme that required some customization, the
themes/your_theme/views folder would be the place to put them.