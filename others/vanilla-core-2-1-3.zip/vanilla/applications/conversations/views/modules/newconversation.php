<?php if (!defined('APPLICATION')) exit();
echo Anchor(T('New Message'), '/messages/add', 'Button BigButton NewConversation Primary');