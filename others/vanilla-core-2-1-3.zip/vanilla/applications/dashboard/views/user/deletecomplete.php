<?php if (!defined('APPLICATION')) exit(); ?>
<h1><?php echo T('User Deleted'); ?></h1>
<div class="Info">
   <?php echo T("The user has been deleted."); ?>
   <br /><?php echo Anchor(T('Back to all users'), '/user'); ?>
</div>