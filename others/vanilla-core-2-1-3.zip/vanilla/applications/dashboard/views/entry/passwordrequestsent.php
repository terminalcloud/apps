<?php if (!defined('APPLICATION')) exit(); ?>
<h1><?php echo T("Reset my password") ?></h1>
<div class="P">
   <p><?php echo T('A message has been sent to your email address with password reset instructions.'); ?></p>
</div>