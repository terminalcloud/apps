<?php if (!defined('APPLICATION')) exit(); ?>

<h1><?php echo T('TermsOfService');?></h1>
<div class="Legal">
   <?php echo Markdown(T('TermsOfServiceText'));?>
</div>