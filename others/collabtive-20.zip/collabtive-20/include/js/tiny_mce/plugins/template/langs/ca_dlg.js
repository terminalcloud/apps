tinyMCE.addI18n('ca.template_dlg',{
title:"Plantilles",
label:"Plantilla",
desc_label:"Descripci\u00F3",
desc:"Insereix contingut predefinit de plantilla",
select:"Selecciona una plantilla",
preview:"Vista pr\u00E8via",
warning:"Atenci\u00F3: Actualitzar una plantilla amb una de diferent pot provocar p\u00E8rdua de dades.",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"Gener,Febrer,Mar\u00E7,Abril,Maig,Juny,Juliol,Agost,Setembre,Octubre,Novembre,Desembre",
months_short:"Gen,Feb,Mar,Abr,Mai,Jun,Jul,Ago,Set,Oct,Nov,Des",
day_long:"Diumenge,Dilluns,Dimarts,Dimecres,Dijous,Divendres,Dissabte,Diumenge",
day_short:"Dmg,Dll,Dmt,Dmc,Djs,Dvs,Dss,Dmg"
});