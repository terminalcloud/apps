<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['AOR_Reports'] = 'AOR_Report';
$beanFiles['AOR_Report'] = 'modules/AOR_Reports/AOR_Report.php';
$moduleList[] = 'AOR_Reports';
$beanList['AOR_Fields'] = 'AOR_Field';
$beanFiles['AOR_Field'] = 'modules/AOR_Fields/AOR_Field.php';
$modules_exempt_from_availability_check['AOR_Fields'] = 'AOR_Fields';
$report_include_modules['AOR_Fields'] = 'AOR_Fields';
$modInvisList[] = 'AOR_Fields';
$beanList['AOR_Charts'] = 'AOR_Chart';
$beanFiles['AOR_Chart'] = 'modules/AOR_Charts/AOR_Chart.php';
$modules_exempt_from_availability_check['AOR_Charts'] = 'AOR_Charts';
$report_include_modules['AOR_Charts'] = 'AOR_Charts';
$modInvisList[] = 'AOR_Charts';
$beanList['AOR_Conditions'] = 'AOR_Condition';
$beanFiles['AOR_Condition'] = 'modules/AOR_Conditions/AOR_Condition.php';
$modules_exempt_from_availability_check['AOR_Conditions'] = 'AOR_Conditions';
$report_include_modules['AOR_Conditions'] = 'AOR_Conditions';
$modInvisList[] = 'AOR_Conditions';

?>