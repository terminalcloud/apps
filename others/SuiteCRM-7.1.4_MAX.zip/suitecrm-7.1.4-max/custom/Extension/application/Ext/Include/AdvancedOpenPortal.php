<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['AOP_Case_Events'] = 'AOP_Case_Events';
$beanFiles['AOP_Case_Events'] = 'modules/AOP_Case_Events/AOP_Case_Events.php';
$modules_exempt_from_availability_check['AOP_Case_Events'] = 'AOP_Case_Events';
$report_include_modules['AOP_Case_Events'] = 'AOP_Case_Events';
$modInvisList[] = 'AOP_Case_Events';
$beanList['AOP_Case_Updates'] = 'AOP_Case_Updates';
$beanFiles['AOP_Case_Updates'] = 'modules/AOP_Case_Updates/AOP_Case_Updates.php';
$modules_exempt_from_availability_check['AOP_Case_Updates'] = 'AOP_Case_Updates';
$report_include_modules['AOP_Case_Updates'] = 'AOP_Case_Updates';
$modInvisList[] = 'AOP_Case_Updates';

?>