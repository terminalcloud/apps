<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['FP_events'] = 'FP_events';
$beanFiles['FP_events'] = 'modules/FP_events/FP_events.php';
$moduleList[] = 'FP_events';
$beanList['FP_Event_Locations'] = 'FP_Event_Locations';
$beanFiles['FP_Event_Locations'] = 'modules/FP_Event_Locations/FP_Event_Locations.php';
$moduleList[] = 'FP_Event_Locations';

?>