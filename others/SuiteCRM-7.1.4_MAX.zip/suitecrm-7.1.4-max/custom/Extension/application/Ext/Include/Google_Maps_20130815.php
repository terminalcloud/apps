<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['jjwg_Maps'] = 'jjwg_Maps';
$beanFiles['jjwg_Maps'] = 'modules/jjwg_Maps/jjwg_Maps.php';
$moduleList[] = 'jjwg_Maps';
$beanList['jjwg_Markers'] = 'jjwg_Markers';
$beanFiles['jjwg_Markers'] = 'modules/jjwg_Markers/jjwg_Markers.php';
$moduleList[] = 'jjwg_Markers';
$beanList['jjwg_Areas'] = 'jjwg_Areas';
$beanFiles['jjwg_Areas'] = 'modules/jjwg_Areas/jjwg_Areas.php';
$moduleList[] = 'jjwg_Areas';
$beanList['jjwg_Address_Cache'] = 'jjwg_Address_Cache';
$beanFiles['jjwg_Address_Cache'] = 'modules/jjwg_Address_Cache/jjwg_Address_Cache.php';
$moduleList[] = 'jjwg_Address_Cache';

?>