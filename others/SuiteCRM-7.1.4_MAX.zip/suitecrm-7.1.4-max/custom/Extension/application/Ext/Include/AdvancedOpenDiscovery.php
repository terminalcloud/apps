<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['AOD_IndexEvent'] = 'AOD_IndexEvent';
$beanFiles['AOD_IndexEvent'] = 'modules/AOD_IndexEvent/AOD_IndexEvent.php';
$modules_exempt_from_availability_check['AOD_IndexEvent'] = 'AOD_IndexEvent';
$report_include_modules['AOD_IndexEvent'] = 'AOD_IndexEvent';
$modInvisList[] = 'AOD_IndexEvent';
$beanList['AOD_Index'] = 'AOD_Index';
$beanFiles['AOD_Index'] = 'modules/AOD_Index/AOD_Index.php';
$modules_exempt_from_availability_check['AOD_Index'] = 'AOD_Index';
$report_include_modules['AOD_Index'] = 'AOD_Index';
$modInvisList[] = 'AOD_Index';

?>