<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['AOS_Contracts'] = 'AOS_Contracts';
$beanFiles['AOS_Contracts'] = 'modules/AOS_Contracts/AOS_Contracts.php';
$moduleList[] = 'AOS_Contracts';
$beanList['AOS_Invoices'] = 'AOS_Invoices';
$beanFiles['AOS_Invoices'] = 'modules/AOS_Invoices/AOS_Invoices.php';
$moduleList[] = 'AOS_Invoices';
$beanList['AOS_PDF_Templates'] = 'AOS_PDF_Templates';
$beanFiles['AOS_PDF_Templates'] = 'modules/AOS_PDF_Templates/AOS_PDF_Templates.php';
$moduleList[] = 'AOS_PDF_Templates';
$beanList['AOS_Product_Categories'] = 'AOS_Product_Categories';
$beanFiles['AOS_Product_Categories'] = 'modules/AOS_Product_Categories/AOS_Product_Categories.php';
$moduleList[] = 'AOS_Product_Categories';
$beanList['AOS_Products'] = 'AOS_Products';
$beanFiles['AOS_Products'] = 'modules/AOS_Products/AOS_Products.php';
$moduleList[] = 'AOS_Products';
$beanList['AOS_Products_Quotes'] = 'AOS_Products_Quotes';
$beanFiles['AOS_Products_Quotes'] = 'modules/AOS_Products_Quotes/AOS_Products_Quotes.php';
$modules_exempt_from_availability_check['AOS_Products_Quotes'] = 'AOS_Products_Quotes';
$report_include_modules['AOS_Products_Quotes'] = 'AOS_Products_Quotes';
$modInvisList[] = 'AOS_Products_Quotes';
$beanList['AOS_Line_Item_Groups'] = 'AOS_Line_Item_Groups';
$beanFiles['AOS_Line_Item_Groups'] = 'modules/AOS_Line_Item_Groups/AOS_Line_Item_Groups.php';
$modules_exempt_from_availability_check['AOS_Line_Item_Groups'] = 'AOS_Line_Item_Groups';
$report_include_modules['AOS_Line_Item_Groups'] = 'AOS_Line_Item_Groups';
$modInvisList[] = 'AOS_Line_Item_Groups';
$beanList['AOS_Quotes'] = 'AOS_Quotes';
$beanFiles['AOS_Quotes'] = 'modules/AOS_Quotes/AOS_Quotes.php';
$moduleList[] = 'AOS_Quotes';

?>