<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['AOW_Actions'] = 'AOW_Action';
$beanFiles['AOW_Action'] = 'modules/AOW_Actions/AOW_Action.php';
$modules_exempt_from_availability_check['AOW_Actions'] = 'AOW_Actions';
$report_include_modules['AOW_Actions'] = 'AOW_Actions';
$modInvisList[] = 'AOW_Actions';
$beanList['AOW_WorkFlow'] = 'AOW_WorkFlow';
$beanFiles['AOW_WorkFlow'] = 'modules/AOW_WorkFlow/AOW_WorkFlow.php';
$moduleList[] = 'AOW_WorkFlow';
$beanList['AOW_Processed'] = 'AOW_Processed';
$beanFiles['AOW_Processed'] = 'modules/AOW_Processed/AOW_Processed.php';
$modules_exempt_from_availability_check['AOW_Processed'] = 'AOW_Processed';
$report_include_modules['AOW_Processed'] = 'AOW_Processed';
$modInvisList[] = 'AOW_Processed';
$beanList['AOW_Conditions'] = 'AOW_Condition';
$beanFiles['AOW_Condition'] = 'modules/AOW_Conditions/AOW_Condition.php';
$modules_exempt_from_availability_check['AOW_Conditions'] = 'AOW_Conditions';
$report_include_modules['AOW_Conditions'] = 'AOW_Conditions';
$modInvisList[] = 'AOW_Conditions';

?>