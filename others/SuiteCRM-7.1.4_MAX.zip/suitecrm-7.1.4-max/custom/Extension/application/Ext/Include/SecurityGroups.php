<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['SecurityGroups'] = 'SecurityGroup';
$beanFiles['SecurityGroup'] = 'modules/SecurityGroups/SecurityGroup.php';
$moduleList[] = 'SecurityGroups';

?>