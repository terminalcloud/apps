<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['Calls_Reschedule'] = 'Calls_Reschedule';
$beanFiles['Calls_Reschedule'] = 'modules/Calls_Reschedule/Calls_Reschedule.php';
$modules_exempt_from_availability_check['Calls_Reschedule'] = 'Calls_Reschedule';
$report_include_modules['Calls_Reschedule'] = 'Calls_Reschedule';
$modInvisList[] = 'Calls_Reschedule';

?>