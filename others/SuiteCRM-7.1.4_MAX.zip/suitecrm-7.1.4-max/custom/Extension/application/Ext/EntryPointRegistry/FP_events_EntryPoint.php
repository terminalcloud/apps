<?php 
	$entry_point_registry['responseEntryPoint'] = array(
	    'file' => 'modules/FP_events/responseEntryPoint.php',
	    'auth' => false
	);