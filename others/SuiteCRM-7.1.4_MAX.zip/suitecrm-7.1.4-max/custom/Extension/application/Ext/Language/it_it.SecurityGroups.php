<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Gestione Gruppi di Sicurezza';
$app_strings['LBL_LOGIN_AS'] = "Inizio attivit� come ";
$app_strings['LBL_LOGOUT_AS'] = "Termine attivit� come ";
$app_strings['LBL_SECURITYGROUP'] = 'Gestione Gruppi';

?>