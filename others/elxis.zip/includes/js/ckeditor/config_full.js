﻿/*****************************************
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license

Elxis CMS - Copyright 2006-2014 elxis.org. All rights reserved.
CKEditor configuration - HTML - Full
******************************************/

CKEDITOR.editorConfig = function( config ) {
	//generic
	config.entities_greek = false;
	config.entities_latin = false;
	config.entities = false;
	config.processNumerical = true;
	config.allowedContent = true;
	//config.width = 900; //elxis 4.2
	//plugins
	//config.bodyClass = 'elx_article_page';
	config.extraPlugins = 'youtube,elxisplugin';
	//config.contentsCss = '/templates/system/css/standard.css';//for plugin stylesheetparser
	config.docType = '<!DOCTYPE html>';
	config.stylesSet = 'default:plugins/styles/default.js';
	config.toolbar = [
	{ name: 'document',    items : [ 'Source','-','Preview','Print','-','Templates' ] },
	{ name: 'clipboard',   items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },
	{ name: 'editing',     items : [ 'Find','Replace','-','SelectAll','-','SpellChecker', 'Scayt' ] },
	{ name: 'forms',       items : [ 'Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField' ] },
	'/',
	{ name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },
	{ name: 'paragraph',   items : [ 'NumberedList','BulletedList','-','Outdent','Indent','-','Blockquote','CreateDiv','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock','-','BidiLtr','BidiRtl' ] },
	{ name: 'insert',      items : [ 'Image','Youtube','Flash','Table','HorizontalRule','Smiley','SpecialChar','PageBreak' ] },
	'/',
	{ name: 'styles',      items : [ 'Styles','Format','Font','FontSize' ] },
	{ name: 'colors',      items : [ 'TextColor','BGColor' ] },
	{ name: 'links',       items : [ 'Link','Unlink','Anchor' ] },
	{ name: 'tools',       items : [ 'Maximize', 'ShowBlocks','-','ElxisPlugin','-','About' ] }
	];
	config.extraAllowedContent = 'code';
};
