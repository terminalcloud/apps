﻿/*
Copyright (c) 2006-2014, Elxis Team - Ioannis Sannos. All rights reserved.
http://www.elxis.org
*/

CKEDITOR.plugins.setLang('elxisplugin', 'en',{
		button: 'Elxis Plugin',
		importplugin: 'Import an Elxis plugin',
		code: 'Code',
		insertplugin: 'Insert plugin',
		help: 'Help',
		plugnoempty: 'Plugin code can not be empty!',
		genplugsyntax: 'Generic plugin syntax:',
		extactdepplug: 'The exact format depends on the plugin.',
		guidedinput: 'Guided input',
		plugmanually: 'Insert manually the plugin code above',
		plugtryguide: 'or try the guided input'
});
