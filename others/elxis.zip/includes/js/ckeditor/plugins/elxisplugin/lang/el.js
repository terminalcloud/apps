﻿/*
Copyright (c) 2006-2014, Elxis Team - Ioannis Sannos. All rights reserved.
http://www.elxis.org
*/

CKEDITOR.plugins.setLang('elxisplugin', 'el',{
		button: 'Πρόσθετο Elxis',
		importplugin: 'Εισαγωγή προσθέτου Elxis',
		code: 'Κώδικας',
		insertplugin: 'Εισαγωγή προσθέτου',
		help: 'Βοήθεια',
		plugnoempty: 'Ο κώδικας του Προσθέτου δεν μπορεί να είναι κενός!',
		genplugsyntax: 'Γενική σύνταξη προσθέτου:',
		extactdepplug: 'Η ακριβής σύνταξη εξαρτάται από το πρόσθετο.',
		guidedinput: 'Καθοδηγούμενη εισαγωγή',
		plugmanually: 'Εισάγετε χειροκίνητα τον κώδικά του προσθέτου',
		plugtryguide: 'ή δοκιμάστε την καθοδηγούμενη εισαγωγή'
});
