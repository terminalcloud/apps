﻿/*****************************************
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license

Elxis CMS - Copyright 2006-2012 elxis.org. All rights reserved.
CKEditor configuration - BBcode - Full
******************************************/


CKEDITOR.editorConfig = function( config ) {
	//generic
	config.basicEntities = false; //elxis 4.2: required for bbcode
	config.entities_greek = false;
	config.entities_latin = false;
	config.entities = false;
	//config.width = 450; //elxis 4.2
	//bbcode specific
	config.extraPlugins = 'bbcode';
	config.removePlugins = 'bidi,button,dialogadvtab,div,filebrowser,flash,format,forms,horizontalrule,iframe,indent,justify,liststyle,pagebreak,showborders,stylescombo,table,tabletools,templates';
	config.disableObjectResizing = true;
	config.fontSize_sizes = '30/30%;50/50%;100/100%;120/120%;150/150%;200/200%;300/300%';
	config.toolbar = [
		['Source', '-','Undo','Redo'],
		['Find','Replace','-','SelectAll','RemoveFormat'],
		['Link', 'Unlink', 'Image', 'Smiley','SpecialChar'],
		'/',
		['Bold', 'Italic','Underline'],
		['FontSize'],
		['TextColor'],
		['NumberedList','BulletedList','-','Blockquote'],
		['Maximize']
	];
	config.smiley_images = [
		'regular_smile.png','sad_smile.png','wink_smile.png','teeth_smile.png','tongue_smile.png','embarrassed_smile.png',
		'omg_smile.png','whatchutalkingabout_smile.png','angel_smile.png','shades_smile.png','cry_smile.png','kiss.png'
	];
	config.smiley_descriptions = [
		'smiley', 'sad', 'wink', 'laugh', 'cheeky', 'blush', 'surprise',
		'indecision', 'angel', 'cool', 'crying', 'kiss'
	];

};
