<?php 
/**
* @version		$Id: fpage.html.php 1514 2014-05-13 18:20:15Z sannosi $
* @package		Elxis
* @subpackage	Component Content
* @copyright	Copyright (c) 2006-2014 Elxis CMS (http://www.elxis.org). All rights reserved.
* @license		Elxis Public License ( http://www.elxis.org/elxis-public-license.html )
* @author		Elxis Team ( http://www.elxis.org )
* @description 	Elxis CMS is free software. Read the license for copyright notices and details
*/

defined('_ELXIS_') or die ('Direct access to this location is not allowed');


class fpageContentView extends contentView {

	/*********************/
	/* MAGIC CONSTRUCTOR */
	/*********************/
	public function __construct() {
		parent::__construct();
	}


	/**********************************/
	/* GENERATE FRONTPAGE LAYOUT HTML */
	/**********************************/
	public function showFrontpage($layout) {
		$this->openWrapper();

		if ($layout->wl > 0) {
			$this->openColumn('l', $layout->resbox1);
			$this->renderBox($layout->c1, $layout->type);
			$this->closeColumn();
		}

		if ($layout->wc > 0) {
			$this->openColumn('c', 1);
			$this->renderCenter($layout);
			$this->closeColumn();
		}

		if ($layout->wr > 0) {
			$this->openColumn('r', $layout->resbox3);
			$this->renderBox($layout->c3, $layout->type);
			$this->closeColumn();
		}

		$this->closeWrapper();
	}


	/***********************/
	/* OPEN GLOBAL WRAPPER */
	/***********************/
	private function openWrapper() {
		echo '<div class="gridzero">'."\n"; 
	}


	/************************/
	/* CLOSE GLOBAL WRAPPER */
	/************************/
	private function closeWrapper() {
		echo '<div class="clear"></div>'."\n";
		echo "</div>\n";
	}


	/***************/
	/* OPEN COLUMN */
	/***************/
	private function openColumn($col, $respshow=1) {
		if ($respshow == 1) {
			echo '<div class="grid'.$col.'col">'."\n";
		} else {
			echo '<div class="grid'.$col.'colh">'."\n";
		}
	}


	/****************/
	/* CLOSE COLUMN */
	/****************/
	private function closeColumn() {
		echo "</div>\n";
	}


	/**********************/
	/* RENDER COLUMN CELL */
	/**********************/
	private function renderBox($items, $type) {
		if ($items) {
			$eDoc = eFactory::getDocument();
			foreach ($items as $item) {
				if ($type == 'positions') {
					$eDoc->modules($item);
				} else {
					$parts = explode(':', $item);
					if (count($parts == 2)) {
						$modid = (int)$parts[1];
						$eDoc->module($modid);//load single module by its ID (Elxis 4.2+)
					}
				}
			}
		} else {
			echo '&#160;';
		}
	}


	/******************************/
	/* RENDER CENTER COLUMN CELLS */
	/******************************/
	private function renderCenter($layout) {
		$something = false;
		if ($layout->c2) {
			$something = true;
			$css = ($layout->resbox2 == 1) ? 'gridcell2' : 'gridcell2h';
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c2, $layout->type);
			echo "</div>\n";
		}

		if (($layout->c4) || ($layout->c5)) {
			$something = true;
			$css = ($layout->resbox4 == 1) ? 'gridcell4' : 'gridcell4h';
			$css2 = ($layout->resbox5 == 1) ? 'gridcell5' : 'gridcell5h';
			echo '<div class="griddspace">'."\n";
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c4, $layout->type);
			echo "</div>\n";
			echo '<div class="'.$css2.'">'."\n";
			$this->renderBox($layout->c5, $layout->type);
			echo "</div>\n";
			echo '<div class="clear">'."</div>\n";
			echo "</div>\n";
		}

		if (($layout->c6) || ($layout->c7)) {
			$something = true;
			$css = ($layout->resbox6 == 1) ? 'gridcell6' : 'gridcell6h';
			$css2 = ($layout->resbox7 == 1) ? 'gridcell7' : 'gridcell7h';
			echo '<div class="griddspace">'."\n";
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c6, $layout->type);
			echo "</div>\n";
			echo '<div class="'.$css2.'">'."\n";
			$this->renderBox($layout->c7, $layout->type);
			echo "</div>\n";
			echo '<div class="clear">'."</div>\n";
			echo "</div>\n";
		}

		if (($layout->c8) || ($layout->c9)) {
			$something = true;
			$css = ($layout->resbox8 == 1) ? 'gridcell8' : 'gridcell8h';
			$css2 = ($layout->resbox9 == 1) ? 'gridcell9' : 'gridcell9h';
			echo '<div class="griddspace">'."\n";
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c8, $layout->type);
			echo "</div>\n";
			echo '<div class="'.$css2.'">'."\n";
			$this->renderBox($layout->c9, $layout->type);
			echo "</div>\n";
			echo '<div class="clear">'."</div>\n";
			echo "</div>\n";
		}

		if ($layout->c10) {
			$something = true;
			$css = ($layout->resbox10 == 1) ? 'gridcell10' : 'gridcell10h';
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c10, $layout->type);
			echo "</div>\n";
		}

		if (($layout->c11) || ($layout->c12) || ($layout->c13)) {
			$something = true;
			$css = ($layout->resbox11 == 1) ? 'gridcell11' : 'gridcell11h';
			$css2 = ($layout->resbox12 == 1) ? 'gridcell12' : 'gridcell12h';
			$css3 = ($layout->resbox13 == 1) ? 'gridcell13' : 'gridcell13h';
			echo '<div class="griddspace">'."\n";
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c11, $layout->type);
			echo "</div>\n";
			echo '<div class="'.$css2.'">'."\n";
			$this->renderBox($layout->c12, $layout->type);
			echo "</div>\n";
			echo '<div class="'.$css3.'">'."\n";
			$this->renderBox($layout->c13, $layout->type);
			echo "</div>\n";
			echo '<div class="clear">'."</div>\n";
			echo "</div>\n";
		}

		if ($layout->c14) {
			$something = true;
			$css = ($layout->resbox14 == 1) ? 'gridcell14' : 'gridcell14h';
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c14, $layout->type);
			echo "</div>\n";
		}

		if (($layout->c15) || ($layout->c16)) {
			$something = true;
			$css = ($layout->resbox15 == 1) ? 'gridcell15' : 'gridcell15h';
			$css2 = ($layout->resbox16 == 1) ? 'gridcell16' : 'gridcell16h';
			echo '<div class="griddspace">'."\n";
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c15, $layout->type);
			echo "</div>\n";
			echo '<div class="'.$css2.'">'."\n";
			$this->renderBox($layout->c16, $layout->type);
			echo "</div>\n";
			echo '<div class="clear">'."</div>\n";
			echo "</div>\n";
		}

		if ($layout->c17) {
			$something = true;
			$css = ($layout->resbox17 == 1) ? 'gridcell17' : 'gridcell17h';
			echo '<div class="'.$css.'">'."\n";
			$this->renderBox($layout->c17, $layout->type);
			echo "</div>\n";
		}

		if (!$something) { echo '&#160;'; }
	}

}

?>