<?php 
/**
* @version: 1.0
* @package: Elxis CMS
* @subpackage: Elxis Language
* @author: Elxis Team ( http://www.elxis.org )
* @copyright: (C) 2006-2013 Elxis.org. All rights reserved.
* @description: tr-TR (Turkish - Turkey) language for plugin Automatic Links
* @license: Elxis public license http://www.elxis.org/elxis-public-license.html
* @translator: Hakan Gür ( http://www.dildersleri.gen.tr )
*
* ---- THIS FILE MUST BE ENCODED AS UTF-8! ----
*
*****************************************************************************/

defined('_ELXIS_') or die ('Doğrudan erişime izin yok.');


$_lang = array();
$_lang['ARTICLES_TAGGED'] = "%s olarak etiketlenmiş yazılar";
$_lang['KEYWORDS'] = 'Anahtar sözcükler';
$_lang['OPT_KEYWORDS'] = 'Seçeneğe başlı anahtar sözcükler';

?>