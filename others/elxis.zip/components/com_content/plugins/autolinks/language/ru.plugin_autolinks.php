<?php 
/**
* @version: 1.0
* @package: Elxis CMS
* @subpackage: Elxis Language
* @author: Elxis Team ( http://www.elxis.org )
* @copyright: (C) 2006-2012 Elxis.org. All rights reserved.
* @description: ru-RU (Russian - Russia) language for plugin Automatic Links
* @license: Elxis public license http://www.elxis.org/elxis-public-license.html
* @translator: Slavakov ( http://www.ekofarm.ukrmed.info )
*
* ---- THIS FILE MUST BE ENCODED AS UTF-8! ----
*
*****************************************************************************/

defined('_ELXIS_') or die ('Доступ запрещен.');


$_lang = array();
$_lang['ARTICLES_TAGGED'] = "Статьи с ключевым словом %s";
$_lang['KEYWORDS'] = 'Ключевые слова';
$_lang['OPT_KEYWORDS'] = 'Дополнительные ключевые слова';

?>