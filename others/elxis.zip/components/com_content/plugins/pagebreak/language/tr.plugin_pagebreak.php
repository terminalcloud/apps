<?php 
/**
* @version: 1.0
* @package: Elxis CMS
* @subpackage: Elxis Language
* @author: Elxis Team ( http://www.elxis.org )
* @copyright: (C) 2006-2013 Elxis.org. All rights reserved.
* @description: en-GB (English - Great Britain) language for plugin Youtube Video
* @license: Elxis public license http://www.elxis.org/elxis-public-license.html
* @translator: Hakan Gür ( http://www.dildersleri.gen.tr )
*
* ---- THIS FILE MUST BE ENCODED AS UTF-8! ----
*
*****************************************************************************/

defined('_ELXIS_') or die ('Doğrudan erişime izin yok.');


$_lang = array();
$_lang['INSERT_CODE'] = 'Kod girin';
$_lang['CLICK_INSERT_PAGEBREAK'] = 'Sayfa bölmeyi oluşturup eklemek için tıklayın.';

?>