/* COMPONENT eMenu JS by Ioannis Sannos (datahell) */

/* SELECT COMPONENT */
function emenu_pickcomponent(cmp) {
	if (typeof cmp == 'undefined') {
		var obj = document.getElementById('pickcomponent');	
    	var component = obj.options[obj.selectedIndex].value;
    } else {
    	component = cmp;
   	}
   	if (component == '') { return; }
	var edata = { 'component': component };
	var eurl = document.getElementById('epremenuurl').value+'mitems/generator.html';
	var loadtext = document.getElementById('eprloadingtxt').value;
	elxAjax('POST', eurl, edata, 'emenu_generator', loadtext, null, null);
}

/* SET MENU ITEM INFO */
function emenu_setlink(xtitle, xlink, secure, alevel) {
	secure = parseInt(secure);
	document.getElementById('eprtitle').value = xtitle;
	document.getElementById('eprlink').value = xlink;
	if (secure == 1) {
		document.getElementById('eprsecure_1').checked = 'checked';
		document.getElementById('eprsecure_2').checked = '';
	} else {
		document.getElementById('eprsecure_1').checked = '';
		document.getElementById('eprsecure_2').checked = 'checked';
	}
	if (typeof alevel != 'undefined') {
		alevel = parseInt(alevel, 10);
		var selObj = document.getElementById('epralevel');
		for (var i=0; i < selObj.options.length; i++) {
			if (selObj.options[i].value == alevel) {
				selObj.selectedIndex = i;
			}
		}
	}
}

/* SET MENU ITEM INFO FROM POPUP WINDOW */
function emenu_osetlink(xtitle, xlink, secure, alevel) {
	secure = parseInt(secure);
	window.opener.document.getElementById('eprtitle').value = xtitle;
	window.opener.document.getElementById('eprlink').value = xlink;
	if (secure == 1) {
		window.opener.document.getElementById('eprsecure_1').checked = 'checked';
		window.opener.document.getElementById('eprsecure_2').checked = '';
	} else {
		window.opener.document.getElementById('eprsecure_1').checked = '';
		window.opener.document.getElementById('eprsecure_2').checked = 'checked';
	}
	if (typeof alevel != 'undefined') {
		alevel = parseInt(alevel, 10);
		var selObj = window.opener.document.getElementById('epralevel');
		for (var i=0; i < selObj.options.length; i++) {
			if (selObj.options[i].value == alevel) {
				selObj.selectedIndex = i;
			}
		}
	}
	window.close();
}

function emenu_copymoveitemcol() {
	var menu_id = parseInt(document.getElementById('cm_menu_id').value, 10);
	var cmaction = document.getElementById('cm_action').value;
	var cmObj = document.getElementById('cm_collection');
	var cmcol = cmObj.options[cmObj.selectedIndex].value;
	var edata = {'menu_id': menu_id, 'action':cmaction, 'collection':cmcol };
	var eurl = document.getElementById('emenu_mitems_base').innerHTML+'copyitemcol';
	var successfunc = function(xreply) {
		var rdata = new Array();
		rdata = xreply.split('|');
		var rok = parseInt(rdata[0]);
		if (rok == 1) {
			$.colorbox.close();
			$("#lmtimes").flexReload();
		} else {
			document.getElementById('cm_response').innerHTML = rdata[1];
		}
	}
	var errorfunc = function (XMLHttpRequest, textStatus, errorThrown) {
		document.getElementById('cm_response').innerHTML = errorThrown;
	}
	elxAjax('POST', eurl, edata, null, null, successfunc, errorfunc);
}
