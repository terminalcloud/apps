<?php 
/**
* @version		$Id: install.html.php 1602 2014-07-04 16:49:05Z sannosi $
* @package		Elxis
* @subpackage	Component Extensions Manager
* @copyright	Copyright (c) 2006-2014 Elxis CMS (http://www.elxis.org). All rights reserved.
* @license		Elxis Public License ( http://www.elxis.org/elxis-public-license.html )
* @author		Elxis Team ( http://www.elxis.org )
* @description 	Elxis CMS is free software. Read the license for copyright notices and details
*/

defined('_ELXIS_') or die ('Direct access to this location is not allowed');


class installExtmanagerView extends extmanagerView {

	/*********************/
	/* MAGIC CONSTRUCTOR */
	/*********************/
	public function __construct() {
		parent::__construct();
	}


	/********************************/
	/* SHOW COMPONENT CONTROL PANEL */
	/********************************/
	public function ipanel($sync) {
		$elxis = eFactory::getElxis();
		$eLang = eFactory::getLang();

		$align = ($eLang->getinfo('DIR') == 'rtl') ? 'right' : 'left';
		$types = array(
			'components' => array('icon' => 'component', 'title' => $eLang->get('COMPONENTS'), 'descr' => $eLang->get('MANAGE_COMPONENTS')),
			'modules' => array('icon' => 'module', 'title' => $eLang->get('MODULES'), 'descr' => $eLang->get('MANAGE_MODULES')),
			'plugins' => array('icon' => 'plugin', 'title' => $eLang->get('CONTENT_PLUGINS'), 'descr' => $eLang->get('MANAGE_CONTENT_PLUGINS')),
			'templates' => array('icon' => 'template', 'title' => $eLang->get('TEMPLATES'), 'descr' => $eLang->get('MANAGE_TEMPLATES')),
			'engines' => array('icon' => 'engine', 'title' => $eLang->get('SEARCH_ENGINES'), 'descr' => $eLang->get('MANAGE_SEARCH_ENGINES')),
			'auth' => array('icon' => 'auth', 'title' => $eLang->get('AUTH_METHODS'), 'descr' => $eLang->get('MANAGE_AUTH_METHODS'))
		);

		$is_subsite = false;
		if (defined('ELXIS_MULTISITE')) {
			$is_subsite = (ELXIS_MULTISITE == 1) ? false : true;
		}

		$can_install = $elxis->acl()->check('com_extmanager', 'components', 'install');
		$can_install += $elxis->acl()->check('com_extmanager', 'modules', 'install');
		$can_install += $elxis->acl()->check('com_extmanager', 'templates', 'install');
		$can_install += $elxis->acl()->check('com_extmanager', 'engines', 'install');
		$can_install += $elxis->acl()->check('com_extmanager', 'auth', 'install');
		$can_install += $elxis->acl()->check('com_extmanager', 'plugins', 'install');
?>
		<h2><?php echo $eLang->get('EXTENSIONS'); ?></h2>
		<div class="extman_wrapper">
			<div class="extman_wraplinks<?php echo $eLang->getinfo('RTLSFX'); ?>">
				<div class="extman_inner<?php echo $eLang->getinfo('RTLSFX'); ?>">
<?php 
		foreach ($types as $k => $type) {
			$icon = $elxis->icon($type['icon'], 32);
			$link = $elxis->makeAURL('extmanager:'.$k.'/');	
			$box_class = 'extman_box'.$eLang->getinfo('RTLSFX').' extman_not'.$eLang->getinfo('RTLSFX');

			if ($elxis->acl()->check('com_extmanager', $k, 'edit') > 0) {
				$box_class = 'extman_box'.$eLang->getinfo('RTLSFX');
			}

			echo '<div class="'.$box_class.'">'."\n";
			echo '<img src="'.$icon.'" alt="'.$k.'" border="0" align="'.$align.'" /> ';
			if ($elxis->acl()->check('com_extmanager', $k, 'edit') > 0) {
				echo '<a href="'.$link.'" class="extman_a">'.$type['title']."</a><br />\n";
				echo $type['descr']."\n";
			} else {
				echo '<strong>'.$type['title']."</strong><br />\n";
				echo $eLang->get('ACCESS_DENIED')."\n";
			}
			echo "</div>\n";						
		}
?>
				</div>
			</div>
			<div class="extman_wrapform<?php echo $eLang->getinfo('RTLSFX'); ?>">
				<div class="extman_browsebox<?php echo $eLang->getinfo('RTLSFX'); ?>">
					<div class="extman_edctitle"><?php echo $eLang->get('ELXISDC'); ?></div>
					<a href="<?php echo $elxis->makeAURL('extmanager:browse/'); ?>" title="EDC live" class="extman_edca"><?php echo $eLang->get('BROWSE_EXTS_LIVE'); ?></a>
				</div>

<?php 
		if ($can_install > 0) {
			if ($elxis->getConfig('SECURITY_LEVEL') > 0) {
				if ($elxis->user()->gid == 1) {
					if ($is_subsite) {
						$this->synchroForm($sync);
					} else {
						$this->installForm($sync);
					}
				}
			} else {
				if ($is_subsite) {
					$this->synchroForm($sync);
				} else {
					$this->installForm($sync);
				}
			}
		}
?>
			</div>
			<div style="clear:both;"></div>
		</div>
<?php 
	}


	/*****************************/
	/* SHOW SYNCRHONIZATION FORM */
	/*****************************/
	private function synchroForm($sync) {
		$elxis = eFactory::getElxis();
		$eLang = eFactory::getLang();

		$can_sync = 0;
		$options_str = '';
		if ($elxis->acl()->check('com_extmanager', 'components', 'install') > 0) {
			$can_sync++;
			if (count($sync['components']) > 0) {
				$options_str .= '<optgroup label="'.$eLang->get('COMPONENTS').'">'."\n";
				foreach ($sync['components'] as $comp) {
					$options_str .= '<option value="'.$comp.'">'.$comp."</option>\n";
				}
				$options_str .= "</optgroup>\n";
			}
		}

		if ($elxis->acl()->check('com_extmanager', 'modules', 'install') > 0) {
			$can_sync++;
			if (count($sync['modules']) > 0) {
				$options_str .= '<optgroup label="'.$eLang->get('MODULES').'">'."\n";
				foreach ($sync['modules'] as $mod) {
					$options_str .= '<option value="'.$mod.'">'.$mod."</option>\n";
				}
				$options_str .= "</optgroup>\n";
			}
		}

		if ($elxis->acl()->check('com_extmanager', 'plugins', 'install') > 0) {
			$can_sync++;
			if (count($sync['plugins']) > 0) {
				$options_str .= '<optgroup label="'.$eLang->get('CONTENT_PLUGINS').'">'."\n";
				foreach ($sync['plugins'] as $plg) {
					$options_str .= '<option value="'.$plg.'">'.$plg."</option>\n";
				}
				$options_str .= "</optgroup>\n";
			}
		}

		if ($elxis->acl()->check('com_extmanager', 'templates', 'install') > 0) {
			$can_sync++;
			if (count($sync['templates']) > 0) {
				$options_str .= '<optgroup label="'.$eLang->get('TEMPLATES').'">'."\n";
				foreach ($sync['templates'] as $tpl) {
					$options_str .= '<option value="'.$tpl.'">'.$tpl."</option>\n";
				}
				$options_str .= "</optgroup>\n";
			}
		}

		if ($elxis->acl()->check('com_extmanager', 'engines', 'install') > 0) {
			$can_sync++;
			if (count($sync['engines']) > 0) {
				$options_str .= '<optgroup label="'.$eLang->get('SEARCH_ENGINES').'">'."\n";
				foreach ($sync['engines'] as $eng) {
					$options_str .= '<option value="'.$eng.'">'.$eng."</option>\n";
				}
				$options_str .= "</optgroup>\n";
			}
		}

		if ($elxis->acl()->check('com_extmanager', 'auth', 'install') > 0) {
			$can_sync++;
			if (count($sync['auths']) > 0) {
				$options_str .= '<optgroup label="'.$eLang->get('AUTH_METHODS').'">'."\n";
				foreach ($sync['auths'] as $eng) {
					$options_str .= '<option value="'.$eng.'">'.$eng."</option>\n";
				}
				$options_str .= "</optgroup>\n";
			}
		}

		if ($can_sync == 0) { return; }

		$align = ($eLang->getinfo('DIR') == 'rtl') ? 'right' : 'left';
		$padding = ($eLang->getinfo('DIR') == 'rtl') ? '0 200px 0 0' : '0 0 0 200px';
		$token = md5(uniqid(rand(), true));
		eFactory::getSession()->set('token_extmansync', $token);
?>
		<form name="extsyncform" class="elx_form" method="post" action="">
			<fieldset class="elx_form_fieldset">
				<legend class="elx_form_legend"><?php echo $eLang->get('SYNCHRONIZATION'); ?></legend>
				<div class="elx_form_row">
					<div class="elx_info"><?php echo $eLang->get('SYNCHRONIZATION_INFO'); ?></div>
				</div>
<?php 
		if ($options_str == '') {
			echo "\t\t\t".'<div class="elx_form_row"><div class="elx_sminfo">'.$eLang->get('ALL_EXT_SYNCHRO')."</div></div>\n";
		} else {
?>
				<div class="elx_form_row">
					<label for="extman_extension" class="elx_form_label" style="width:200px; text-align:<?php echo $align; ?>;"><?php echo $eLang->get('EXTENSION'); ?>*</label> 
					<select name="extension" id="extman_extension" title="<?php echo $eLang->get('EXTENSION'); ?>" class="selectbox" dir="ltr">
					<option value="" selected="selected">- <?php echo $eLang->get('SELECT'); ?> -</option>
					<?php echo $options_str; ?>
					</select>
					<input type="hidden" name="token" id="extman_token" value="<?php echo $token; ?>" />
					<button type="button" name="syncsub" id="extm_syncsub" title="<?php echo $eLang->get('SYNCHRONIZE'); ?>" class="extman_button" dir="ltr" onclick="syncElxisExtension();"><?php echo $eLang->get('SYNCHRONIZE'); ?></button>
				</div>
				<div style="margin:10px 0; padding:<?php echo $padding; ?>;">
					<div id="extman_loading" style="display:none;">
						<?php echo $eLang->get('SYNCHRO_IN_PROGRESS'); ?><br />
						<img src="<?php echo $elxis->secureBase(); ?>/components/com_extmanager/css/progress_bar.gif" alt="loading" border="0" />
					</div>
					<div id="extman_response"></div>
				</div>
<?php 
		}
?>
			</fieldset>
		</form>
		<div id="extman_syncurl" class="extman_invisible"><?php echo $elxis->makeAURL('extmanager:install/synchro', 'inner.php'); ?></div>
		<div id="extman_lng_noext" class="extman_invisible"><?php echo $eLang->get('NO_EXT_SELECTED'); ?></div>
		<div id="extman_lng_wait" class="extman_invisible"><?php echo $eLang->get('PLEASE_WAIT'); ?></div>
		<div id="extman_lng_synchronize" class="extman_invisible"><?php echo $eLang->get('SYNCHRONIZE'); ?></div>
		<div id="extman_lng_synsuccess" class="extman_invisible"><?php printf($eLang->get('EXT_SYNC_SUCCESS'), 'X1', 'X2'); ?></div>
		<div id="extman_lng_edit" class="extman_invisible"><?php echo $eLang->get('EDIT'); ?></div>
<?php 
	}


	/*********************/
	/* SHOW INSTALL FORM */
	/*********************/
	private function installForm($sync=false) {
		$elxis = eFactory::getElxis();
		$eLang = eFactory::getLang();

		$align = ($eLang->getinfo('DIR') == 'rtl') ? 'right' : 'left';
		$padding = ($eLang->getinfo('DIR') == 'rtl') ? '0 200px 0 0' : '0 0 0 200px';
		$token = md5(uniqid(rand(), true));
		eFactory::getSession()->set('token_extmaninst', $token);		
		$action = $elxis->makeAURL('extmanager:install/install.html', 'inner.php');
?>
		<form name="extinstform" class="elx_form" method="post" action="<?php echo $action; ?>" enctype="multipart/form-data" target="extman_uptarget" onsubmit="return uploadElxisExtension();">
			<fieldset class="elx_form_fieldset">
				<legend class="elx_form_legend"><?php echo $eLang->get('INSTALL').' /'.$eLang->get('UPDATE'); ?></legend>
				<div class="elx_form_row">
					<div class="elx_info"><?php echo $eLang->get('SEL_PACKAGE_INSTALL').'<br />'.$eLang->get('UPDATE_UPLOAD_NEW').'<br />'.$eLang->get('CONSIDER_DEV_NOTES_UPD'); ?></div>
				</div>
				<div class="elx_form_row">
					<label for="extman_package" class="elx_form_label" style="width:200px; text-align:<?php echo $align; ?>;"><?php echo $eLang->get('PACKAGE'); ?>*</label> 
					<input type="file" name="package" id="extman_package" value="" title="<?php echo $eLang->get('PACKAGE'); ?>" class="filebox" dir="ltr" accept="application/zip|application/x-zip|application/x-zip-compressed" />
					<input type="hidden" name="token" id="extman_token" value="<?php echo $token; ?>" />
					<button type="submit" name="instsub" id="extm_instsub" title="<?php echo $eLang->get('UPLOAD_INSTALL'); ?>" class="extman_button" dir="ltr"><?php echo $eLang->get('UPLOAD_INSTALL'); ?></button>
				</div>
				<div style="margin:10px 0; padding:<?php echo $padding; ?>;">
					<div id="extman_loading" style="display:none;">
						<?php echo $eLang->get('INSTALL_IN_PROGRESS'); ?><br />
						<img src="<?php echo $elxis->secureBase(); ?>/components/com_extmanager/css/progress_bar.gif" alt="loading" border="0" />
					</div>
					<div id="extman_response" style="display:none;"></div>
				</div>

				<iframe id="extman_uptarget" name="extman_uptarget" src="" style="margin:0;padding:0;border:none;width:0;height:0;"></iframe>
			</fieldset>
		</form>

		<div id="extman_baseurl" class="extman_invisible"><?php echo $elxis->makeAURL('extmanager:/', 'inner.php'); ?></div>
		<div id="extman_lng_nopack" class="extman_invisible"><?php echo $eLang->get('NO_PACK_SELECTED'); ?></div>
		<div id="extman_lng_mustzip" class="extman_invisible"><?php echo $eLang->get('ELXIS_PACK_MUST_ZIP'); ?></div>
		<div id="extman_lng_wait" class="extman_invisible"><?php echo $eLang->get('PLEASE_WAIT'); ?></div>
		<div id="extman_lng_upinstall" class="extman_invisible"><?php echo $eLang->get('UPLOAD_INSTALL'); ?></div>
		<div id="extman_lng_syswarns" class="extman_invisible"><?php echo $eLang->get('SYSTEM_WARNINGS'); ?></div>
		<div id="extman_lng_continst" class="extman_invisible"><?php echo $eLang->get('CONTINUE_INSTALL'); ?></div>
		<div id="extman_lng_aboutinstall" class="extman_invisible"><?php printf($eLang->get('ABOUT_TO_INSTALL'), 'X1', 'X2'); ?></div>
		<div id="extman_lng_aboutupdate" class="extman_invisible"><?php printf($eLang->get('ABOUT_TO_UPDATE'), 'X1', 'X2', 'X3'); ?></div>
		<div id="extman_lng_insuccess" class="extman_invisible"><?php printf($eLang->get('EXT_INST_SUCCESS'), 'X1', 'X2'); ?></div>
		<div id="extman_lng_edit" class="extman_invisible"><?php echo $eLang->get('EDIT'); ?></div>
<?php 
	}


	/***************************/
	/* SHOW INSTALLATION ERROR */
	/***************************/
	public function installError($system, $errormsg) {
		if ($errormsg == '') { $errormsg = 'Installation failed! Unknown error.'; }
		if ($system) {
			$this->ajaxHeaders('application/json');
		}
		$response = array('error' => 1, 'errormsg' => addslashes($errormsg));
		echo json_encode($response);
		if ($system) { exit(); }
	}


	/******************/
	/* CONFIRM UPDATE */
	/******************/
	public function confirmUpdate($installer) {
		$current = $installer->getCurrent();
		$head = $installer->getHead();
		$response = array (
			'extension' => $head->name,
			'exttype' => $head->type,
			'version' => $head->version,
			'curversion' => $current['version'],
			'error' => 0,
			'errormsg' => '',
			'confirmup' => 1,
			'confirmin' => 0,
			'ufolder' => $installer->getUfolder(),
			'warnings' => $installer->getWarnings(),
			'success' => 0,
			'editlink' => ''
		);

		echo json_encode($response);
	}


	/*******************/
	/* CONFIRM INSTALL */
	/*******************/
	public function confirmInstall($installer) {
		$head = $installer->getHead();
		$response = array (
			'extension' => $head->name,
			'exttype' => $head->type,
			'version' => $head->version,
			'curversion' => 0,
			'error' => 0,
			'errormsg' => '',
			'confirmup' => 0,
			'confirmin' => 1,
			'ufolder' => $installer->getUfolder(),
			'warnings' => $installer->getWarnings(),
			'success' => 0,
			'editlink' => ''
		);

		echo json_encode($response);
	}


	/*****************************/
	/* SHOW INSTALLATION SUCCESS */
	/*****************************/
	public function installSuccess($system, $installer) {
		$elxis = eFactory::getElxis();

		$head = $installer->getHead();

		$lastid = $installer->getLastID();
		$editlink = '';
		if ($lastid > 0) {
			switch ($head->type) {
				case 'component': $editlink = $elxis->makeAURL('extmanager:components/edit.html').'?id='.$lastid; break;
				case 'module': $editlink = $elxis->makeAURL('extmanager:modules/edit.html').'?id='.$lastid; break;
				case 'plugin': $editlink = $elxis->makeAURL('extmanager:plugins/edit.html').'?id='.$lastid; break;
				case 'engine': $editlink = $elxis->makeAURL('extmanager:engines/edit.html').'?id='.$lastid; break;
				case 'auth': $editlink = $elxis->makeAURL('extmanager:auth/edit.html').'?id='.$lastid; break;
				case 'template': case 'atemplate': $editlink = $elxis->makeAURL('extmanager:templates/edit.html').'?id='.$lastid; break;
				default: break;
			}
		}

		if ($system) {
			$this->ajaxHeaders('application/json');
		}

		$response = array (
			'extension' => $head->name,
			'exttype' => $head->type,
			'version' => $head->version,
			'curversion' => 0,
			'error' => 0,
			'errormsg' => '',
			'confirmup' => 0,
			'confirmin' => 0,
			'ufolder' => '',
			'warnings' => $installer->getWarnings(),
			'success' => 1,
			'editlink' => $editlink
		);

		echo json_encode($response);
		if ($system) { exit(); }
	}


	/**************************/
	/* VIEW AVAILABLE UPDATES */
	/**************************/
	public function updates($extensions, $elxis_releases, $errormsg, $elxisid, $edcauth, $dbupdated) {
		$eLang = eFactory::getLang();
		$elxis = eFactory::getElxis();
		$eDate = eFactory::getDate();

		$icon_package = $elxis->secureBase().'/components/com_extmanager/css/download.png';
		$icon_wait = $elxis->secureBase().'/components/com_extmanager/css/wait16.gif';
		$icon_link = $elxis->icon('link', 16);
		$icon_tick = $elxis->icon('tick', 16);
		$icon_warning = $elxis->icon('warning', 16);
		$icon_not_found = $elxis->icon('not_found', 16);
		$rtl_sfx = $eLang->getinfo('RTLSFX');

		echo '<h2>'.$eLang->get('CHECK_UPDATES')."</h2>\n";

		if ($errormsg != '') {
			echo '<div class="elx_error">'.$errormsg."</div>\n";
		}

		$elxis_idate = $elxis->fromVersion('RELDATE');
		$elxis_ilongversion = 'Elxis '.$elxis->getVersion().' '.$elxis->fromVersion('STATUS').' ['.$elxis->fromVersion('CODENAME').'] rev'.$elxis->fromVersion('REVISION');

		echo "<h3>Elxis</h3>\n";

		if ($elxis_releases['error'] != '') {
			echo '<div class="elx_error">'.$elxis_releases['error']."</div>\n";
		}

		echo '<div class="elx_cols_wrapper">'."\n";
		echo '<div class="elx_2spcolumns">'."\n";
		echo '<div class="elx_tbl_wrapper">'."\n";
		echo '<table cellspacing="0" cellpadding="2" border="1" width="100%" dir="'.$eLang->getinfo('DIR').'" class="elx_tbl_list">'."\n";
		echo '<tr><th colspan="4">'.$eLang->get('INSTALLED_VERSION').'</th></tr>'."\n";
		echo "<tr>\n";
		echo '<th class="elx_th_subcenter">&#160;</th>'."\n";
		echo '<th class="elx_th_subcenter">'.$eLang->get('VERSION')."</th>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('NAME')."</th>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('DATE')."</th>\n";
		echo "</tr>\n";
		$class = 'elx_tr0';
		$current = trim($elxis_releases['current']);
		$ielxis_note = '';
		if ($current != '') {
			if ($current > $elxis->getVersion()) {
				$class = 'elx_trx';
				$imghtml = '<img src="'.$icon_warning.'" alt="Outdated" title="There is a newer Elxis version ('.$elxis_releases['current'].') available!" />';
			} else if ($current < $elxis->getVersion()) {
				$imghtml = '<img src="'.$icon_tick.'" alt="Up To Date" title="You have a newer - possible under development- Elxis version installed." />';
			} else {
				$imghtml = '<img src="'.$icon_tick.'" alt="Up To Date" title="You have the latest Elxis version installed." />';
				if (isset($elxis_releases['rows'][$current])) {
					$irev = $elxis->fromVersion('REVISION');
					if ($elxis_releases['rows'][$current]['revision'] > $irev) {
						$ielxis_note = 'There is an updated release (rev'.$elxis_releases['rows'][$current]['revision'].') of the Elxis version you have installed (rev'.$irev.'). You might consider update.';
					}
				}
			}
		} else {
			$imghtml = '<img src="'.$icon_not_found.'" alt="Unknown" title="Elxis could not determine if you have the latest Elxis version installed." />';
		}
		echo '<tr class="'.$class.'">'."\n";
		echo '<td class="elx_td_center">'.$imghtml."</td>\n";
		echo '<td class="elx_td_center"><strong>'.$elxis->getVersion()."</strong></td>\n";
		echo '<td>'.$elxis_ilongversion."</td>\n";
		echo '<td>'.$eDate->formatDate($elxis_idate, $eLang->get('DATE_FORMAT_5'))."</td>\n";
		echo "</tr>\n";

		if (!$dbupdated) {
			$txt = sprintf($eLang->get('DB_NEEDSUP'), '<strong>'.$elxis->getVersion().'</strong>');
			$updlink = $elxis->makeAURL('extmanager:install/updatedb.html', 'inner.php');
			echo '<tr class="elx_trx"><td colspan="4" class="elx_td_center">'.$txt.'<br /><a href="'.$updlink.'" style="font-weight:bold;">'.$eLang->get('UPDATE').'</a></td></tr>'."\n";
		}

		if ($ielxis_note != '') {
			echo '<tr class="elx_trx"><td colspan="4">'.$ielxis_note.'</td></tr>'."\n";
		}
		echo "</table>\n";
		echo "</div>\n";
		echo "</div>\n";
		echo '<div class="elx_2columns">'."\n";
		echo '<div class="elx_tbl_wrapper">'."\n";
		echo '<table cellspacing="0" cellpadding="2" border="1" width="100%" dir="'.$eLang->getinfo('DIR').'" class="elx_tbl_list">'."\n";
		echo '<tr><th colspan="4">Elxis.org</th></tr>'."\n";
		echo "<tr>\n";
		echo '<th class="elx_th_subcenter">&#160;</th>'."\n";
		echo '<th class="elx_th_subcenter">'.$eLang->get('VERSION')."</th>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('NAME')."</th>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('DATE')."</th>\n";
		echo "</tr>\n";
		if ($elxis_releases['rows']) {
			$k = 1;
			foreach ($elxis_releases['rows'] as $version => $release) {
				if (($current != '') && ($current == $version)) {
					$imghtml = '<img src="'.$icon_tick.'" alt="Current" title="Current latest public Elxis version" />';
				} else {
					$imghtml = '';
				}
				if ($release['status'] != 'Stable') {
					$longversion = 'Elxis '.$release['version'].' <span style="color:#FF0000;">'.$release['status'].'</span> ['.$release['codename'].'] rev'.$release['revision'];
				} else {
					$longversion = 'Elxis '.$release['version'].' '.$release['status'].' ['.$release['codename'].'] rev'.$release['revision'];
				}
				if ($release['link'] != '') {
					$longversion = '<a href="'.$release['link'].'" target="_blank" title="Elxis '.$release['version'].' release details">'.$longversion.'</a>';
				}
				echo '<tr class="elx_tr'.$k.'">'."\n";
				echo '<td class="elx_td_center">'.$imghtml."</td>\n";
				echo '<td class="elx_td_center"><strong>'.$release['version']."</strong></td>\n";
				echo '<td>'.$longversion."</td>\n";
				echo '<td>'.$eDate->formatDate($release['reldate'], $eLang->get('DATE_FORMAT_5'))."</td>\n";
				echo "</tr>\n";
				$k = 1 - $k;
			}
		} else {
			echo '<tr class="elx_trx"><td colspan="4" class="elx_td_center">Could not load data for Elxis releases</td></tr>'."\n";
		}
		echo "</table>\n";
		echo "</div>\n";
		echo "</div>\n";
		echo '<div class="clear">'."</div>\n";
		echo "</div><br />\n";

		echo '<h3>'.$eLang->get('EXTENSIONS')."</h3>\n";

		if ($errormsg != '') {
			echo '<div class="elx_error">'.$errormsg."</div>\n";
		}

		echo '<div class="elx_tbl_wrapper">'."\n";
		echo '<table cellspacing="0" cellpadding="2" border="1" width="100%" dir="'.$eLang->getinfo('DIR').'" class="elx_tbl_list">'."\n";
		echo '<tr><th colspan="2">'.$eLang->get('EXTENSION_INFO').'</th><th colspan="2">'.$eLang->get('INSTALLED_VERSION').'</th><th colspan="3">'.$eLang->get('VERSION').' EDC</th><th></th></tr>'."\n";
		echo "<tr>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('EXTENSION')."</th>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('AUTHOR')."</th>\n";
		echo '<th class="elx_th_subcenter">'.$eLang->get('VERSION')."</th>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('DATE')."</th>\n";
		echo '<th class="elx_th_subcenter">'.$eLang->get('VERSION')."</th>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('DATE')."</th>\n";
		echo '<th class="elx_th_sub">'.$eLang->get('COMPATIBILITY')."</th>\n";
		echo '<th class="elx_th_subcenter">'.$eLang->get('ACTIONS')."</th>\n";
		echo "</tr>\n";
		if ($extensions) {
			$k = 0;
			$i = 1;
			foreach ($extensions as $ext) {
				if (intval($ext['modified']) > 0) {
					$dt = $eDate->formatTS($ext['modified'], $eLang->get('DATE_FORMAT_3'));
				} else if (intval($ext['created']) > 0) {
					$dt = $eDate->formatTS($ext['created'], $eLang->get('DATE_FORMAT_3'));
				} else {
					$dt = '';
				}
				$dt_inst = '';
				if (trim($ext['inst_date']) != '') {
					$dt_inst = $eDate->formatDate($ext['inst_date'], $eLang->get('DATE_FORMAT_3'));
				}
				$tr_class = 'elx_tr'.$k;
				$inst_version = $ext['inst_version'];
				$edc_version = $ext['version'];
				$has_update = false;
				if (($ext['inst_version'] != '') && ($ext['version'] != '')) {
					if ($ext['inst_version'] >= $ext['version']) {
						$inst_version = '<span style="color:#008000; font-weight:bold;" title="'.$eLang->get('UPDATED').'">'.$ext['inst_version'].'</span>';
					} else {
						if ($ext['pcode'] != '') { $has_update = true; }
						$inst_version = '<span style="color:#FF0000; font-weight:bold;">'.$ext['inst_version'].'</span>';
						$edc_version = '<span style="font-weight:bold;">'.$ext['version'].'</span>';
						$tr_class = 'elx_trx';
					}
				}
				$compatibility = '';
				if ($ext['compatibility'] != '') {
					if (strpos($ext['compatibility'], '4') === 0) {
						$compatibility = 'Elxis '.$ext['compatibility'];
					} else {
						$compatibility = $ext['compatibility'];
					}
				}
				echo '<tr class="'.$tr_class.'" id="extrow'.$i.'">'."\n";
				echo '<td><span class="extman_type_'.$ext['type'].$rtl_sfx.'" title="'.$ext['type'].'">'.$ext['title']."</span></td>\n";
				echo '<td>'.$ext['author']."</td>\n";
				echo '<td class="elx_td_center" id="extrow'.$i.'iv">'.$inst_version."</td>\n";
				echo '<td>'.$dt_inst."</td>\n";
				echo '<td class="elx_td_center" id="extrow'.$i.'v">'.$edc_version."</td>\n";
				echo '<td>'.$dt."</td>\n";
				echo '<td>'.$compatibility."</td>\n";
				echo '<td class="elx_td_center">';
				if ($has_update) {
					echo '<span id="extrow'.$i.'dlw"><a href="javascript:void(null);" onclick="edcXUpdate(\''.$ext['pcode'].'\', '.$i.');" title="'.$eLang->get('UPDATE').' '.$ext['title'].'">';
					echo '<img src="'.$icon_package.'" alt="'.$eLang->get('UPDATE').'" id="extrow'.$i.'dli" /></a></span> '."\n";
				}
				if ($ext['edclink'] != '') {
					echo '<a href="'.$ext['edclink'].'" title="'.$ext['title'].' on EDC" target="_blank"><img src="'.$icon_link.'" alt="edc" /></a>';
				}
				echo '</td>'."\n";
				echo "</tr>\n";
				$k = 1 - $k;
				$i++;
			}
		} else {
			echo '<tr class="elx_tr0"><td colspan="8" class="elx_td_center">'.$eLang->get('NO_EXTS_FOUND')."</td></tr>\n";
		}
		echo "</table>\n";
		echo "</div>\n";

		echo '<div id="extmanbase" style="display:none; visibility:hidden;" dir="ltr">'.$elxis->makeAURL('extmanager:/', 'inner.php')."</div>\n";
		echo '<div id="elxisid" style="display:none; visibility:hidden;" dir="ltr">'.$elxisid."</div>\n";
		echo '<div id="edcauth" style="display:none; visibility:hidden;" dir="ltr">'.$edcauth."</div>\n";
		echo '<div id="extwaiticon" style="display:none; visibility:hidden;" dir="ltr">'.$icon_wait."</div>\n";
		echo '<div id="extpackicon" style="display:none; visibility:hidden;" dir="ltr">'.$icon_package."</div>\n";
	}

}

?>