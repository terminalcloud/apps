<?php
/**
 * This is the HTML footer include template.
 *
 * This will be included ONLY for sitewide pages (like a global 404).
 * When a blog is displayed, it is /skins/_html_header.inc.php that will be used
 *
 * @package siteskins
 */
if( !defined('EVO_MAIN_INIT') ) die( 'Please, do not access this page directly.' );
?>
<!-- End of skin_wrapper -->

<!-- /div -->

</body>
</html>